# -*- coding: utf-8 -*-
"""
Logique métier — Comparaison des soldes
Report Finance  vs  Balance Détaillée

Aucun import Streamlit ici : ce module est testable et réutilisable seul.

Règles :
  - Les lignes du Report Finance SANS MATRICULE_CLIENT sont exclues AVANT tout calcul
    (elles n'apparaissent donc jamais dans les écarts).
  - On ne sort que les comptes qui expliquent l'écart entre les deux fichiers :
      * présents des deux côtés avec solde différent
      * présents uniquement dans un fichier (l'autre côté vaut alors 0)
  - Un écart est calculé séparément pour le solde début de mois et le solde fin de mois.
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

# --------------------------------------------------------------------------------------
# Utilitaires
# --------------------------------------------------------------------------------------


def normalize(s: str) -> str:
    """Enlève les accents, met en minuscule et nettoie les espaces."""
    s = unicodedata.normalize("NFKD", str(s))
    s = "".join(c for c in s if not unicodedata.combining(c))
    s = s.replace("_", " ")
    return re.sub(r"\s+", " ", s).strip().lower()


def read_file(uploaded_file) -> pd.DataFrame:
    """Lit un CSV ou un Excel (objet fichier Streamlit ou chemin)."""
    name = getattr(uploaded_file, "name", str(uploaded_file)).lower()
    if name.endswith(".csv"):
        return pd.read_csv(uploaded_file, sep=None, engine="python")
    return pd.read_excel(uploaded_file)


def clean_numeric(series: pd.Series) -> pd.Series:
    """Convertit une colonne de soldes (texte ou nombre, format FR ou EN) en float."""

    def conv(v):
        if pd.isna(v):
            return np.nan
        if isinstance(v, (int, float, np.integer, np.floating)):
            return float(v)
        s = str(v).strip().replace("\xa0", "").replace(" ", "")
        if s == "":
            return np.nan
        neg = False
        if s.startswith("(") and s.endswith(")"):
            neg = True
            s = s[1:-1]
        if "," in s and "." in s:
            s = s.replace(".", "").replace(",", ".")   # 1.234,56 -> 1234.56
        elif "," in s:
            s = s.replace(",", ".")
        s = re.sub(r"[^0-9\.\-]", "", s)
        if s in ("", "-", "."):
            return np.nan
        try:
            val = float(s)
            return -val if neg else val
        except ValueError:
            return np.nan

    return series.apply(conv)


def clean_account_key(series: pd.Series) -> pd.Series:
    """Normalise les numéros de compte pour permettre le rapprochement entre les 2 fichiers."""
    s = series.astype(str).str.strip()
    s = s.str.replace(r"\.0$", "", regex=True)
    s = s.str.replace(r"[^0-9A-Za-z]", "", regex=True)
    s = s.str.lstrip("0")
    return s.replace("", "0")


def fmt(x) -> str:
    """Formatage FR : 1 234 567,89"""
    try:
        return f"{float(x):,.2f}".replace(",", " ").replace(".", ",")
    except (TypeError, ValueError):
        return str(x)


# --------------------------------------------------------------------------------------
# Détection des colonnes
# --------------------------------------------------------------------------------------


class ColonnesManquantes(Exception):
    def __init__(self, fichier: str, colonnes: list, disponibles: list):
        self.fichier = fichier
        self.colonnes = colonnes
        self.disponibles = disponibles
        super().__init__(f"Colonnes manquantes dans {fichier} : {colonnes}")


@dataclass
class Colonnes:
    account1: str
    matricule: str
    ouverture: str
    final1: str
    account2: str
    debut2: str
    fin2: str


def _exact(colmap: dict, target: str):
    return colmap.get(normalize(target))


def _startswith(colmap: dict, prefix: str):
    p = normalize(prefix)
    for norm, orig in colmap.items():
        if norm.startswith(p):
            return orig
    return None


def detecter_colonnes(df1: pd.DataFrame, df2: pd.DataFrame) -> Colonnes:
    colmap1 = {normalize(c): c for c in df1.columns}
    colmap2 = {normalize(c): c for c in df2.columns}

    account1 = _exact(colmap1, "ACCOUNT_NO")
    matricule = _exact(colmap1, "MATRICULE_CLIENT")
    ouverture = _startswith(colmap1, "SOLDE_OUVERTURE")
    final1 = _startswith(colmap1, "SOLDE_FINAL")

    account2 = _exact(colmap2, "Numéro de compte")
    debut2 = _exact(colmap2, "Solde debut de mois")
    fin2 = _exact(colmap2, "Solde fin de mois")

    manquantes1 = [n for n, v in [
        ("ACCOUNT_NO", account1),
        ("MATRICULE_CLIENT", matricule),
        ("SOLDE_OUVERTURE <date>", ouverture),
        ("SOLDE_FINAL <date>", final1),
    ] if v is None]
    if manquantes1:
        raise ColonnesManquantes("Report Finance", manquantes1, list(df1.columns))

    manquantes2 = [n for n, v in [
        ("Numéro de compte", account2),
        ("Solde debut de mois", debut2),
        ("Solde fin de mois", fin2),
    ] if v is None]
    if manquantes2:
        raise ColonnesManquantes("Balance Détaillée", manquantes2, list(df2.columns))

    return Colonnes(account1, matricule, ouverture, final1, account2, debut2, fin2)


# --------------------------------------------------------------------------------------
# Préparation des données
# --------------------------------------------------------------------------------------


def preparer_report_finance(df1_raw: pd.DataFrame, cols: Colonnes):
    """Filtre les lignes sans matricule, nettoie et regroupe par compte.

    Retourne (DataFrame, nb_lignes_ignorees, nb_doublons).
    """
    mat = df1_raw[cols.matricule].astype(str).str.strip().str.lower()
    mask = df1_raw[cols.matricule].notna() & ~mat.isin(["", "nan", "none", "null"])
    df1 = df1_raw[mask].copy()
    nb_ignorees = len(df1_raw) - len(df1)

    r1 = df1[[cols.account1, cols.ouverture, cols.final1]].copy()
    r1.columns = ["ACCOUNT_NO", "SOLDE_DEBUT_F1", "SOLDE_FIN_F1"]
    r1["SOLDE_DEBUT_F1"] = clean_numeric(r1["SOLDE_DEBUT_F1"])
    r1["SOLDE_FIN_F1"] = clean_numeric(r1["SOLDE_FIN_F1"])
    r1["ACCOUNT_KEY"] = clean_account_key(r1["ACCOUNT_NO"])

    nb_doublons = int(r1["ACCOUNT_KEY"].duplicated().sum())
    r1 = r1.groupby("ACCOUNT_KEY", as_index=False).agg(
        ACCOUNT_NO=("ACCOUNT_NO", "first"),
        SOLDE_DEBUT_F1=("SOLDE_DEBUT_F1", "sum"),
        SOLDE_FIN_F1=("SOLDE_FIN_F1", "sum"),
    )
    return r1, nb_ignorees, nb_doublons


def preparer_balance(df2_raw: pd.DataFrame, cols: Colonnes):
    """Nettoie et regroupe la Balance Détaillée par compte. Retourne (DataFrame, nb_doublons)."""
    r2 = df2_raw[[cols.account2, cols.debut2, cols.fin2]].copy()
    r2.columns = ["NUM_COMPTE", "SOLDE_DEBUT_F2", "SOLDE_FIN_F2"]
    r2["SOLDE_DEBUT_F2"] = clean_numeric(r2["SOLDE_DEBUT_F2"])
    r2["SOLDE_FIN_F2"] = clean_numeric(r2["SOLDE_FIN_F2"])
    r2["ACCOUNT_KEY"] = clean_account_key(r2["NUM_COMPTE"])

    nb_doublons = int(r2["ACCOUNT_KEY"].duplicated().sum())
    r2 = r2.groupby("ACCOUNT_KEY", as_index=False).agg(
        NUM_COMPTE=("NUM_COMPTE", "first"),
        SOLDE_DEBUT_F2=("SOLDE_DEBUT_F2", "sum"),
        SOLDE_FIN_F2=("SOLDE_FIN_F2", "sum"),
    )
    return r2, nb_doublons


# --------------------------------------------------------------------------------------
# Comparaison
# --------------------------------------------------------------------------------------


@dataclass
class Resultat:
    ecarts_debut: pd.DataFrame          # uniquement les comptes qui causent l'écart (début)
    ecarts_fin: pd.DataFrame            # uniquement les comptes qui causent l'écart (fin)
    total_debut_f1: float = 0.0
    total_debut_f2: float = 0.0
    total_fin_f1: float = 0.0
    total_fin_f2: float = 0.0
    nb_comptes_f1: int = 0
    nb_comptes_f2: int = 0
    nb_lignes_ignorees: int = 0
    doublons: tuple = field(default=(0, 0))

    @property
    def ecart_total_debut(self) -> float:
        return self.total_debut_f1 - self.total_debut_f2

    @property
    def ecart_total_fin(self) -> float:
        return self.total_fin_f1 - self.total_fin_f2

    @property
    def ecart_explique_debut(self) -> float:
        return float(self.ecarts_debut["ECART"].sum()) if len(self.ecarts_debut) else 0.0

    @property
    def ecart_explique_fin(self) -> float:
        return float(self.ecarts_fin["ECART"].sum()) if len(self.ecarts_fin) else 0.0


def _construire_ecarts(merged: pd.DataFrame, col_f1: str, col_f2: str, tolerance: float) -> pd.DataFrame:
    """Ne garde que les comptes dont le solde diffère entre les deux fichiers."""
    d = merged.copy()
    d["SOLDE_F1"] = d[col_f1].fillna(0.0)
    d["SOLDE_F2"] = d[col_f2].fillna(0.0)
    d["ECART"] = d["SOLDE_F1"] - d["SOLDE_F2"]
    d["ORIGINE"] = np.select(
        [d["_merge"] == "left_only", d["_merge"] == "right_only"],
        ["Absent de la Balance Détaillée", "Absent du Report Finance"],
        default="Présent dans les deux",
    )
    d = d[d["ECART"].abs() > tolerance]
    d = d.assign(ABS=d["ECART"].abs()).sort_values("ABS", ascending=False).drop(columns="ABS")
    return d[["ACCOUNT_NO", "SOLDE_F1", "SOLDE_F2", "ECART", "ORIGINE"]].reset_index(drop=True)


def comparer(r1: pd.DataFrame, r2: pd.DataFrame, tolerance: float = 1.0,
             nb_lignes_ignorees: int = 0, doublons: tuple = (0, 0)) -> Resultat:
    merged = pd.merge(r1, r2, on="ACCOUNT_KEY", how="outer", indicator=True)
    merged["ACCOUNT_NO"] = merged["ACCOUNT_NO"].fillna(merged["NUM_COMPTE"])

    ecarts_debut = _construire_ecarts(merged, "SOLDE_DEBUT_F1", "SOLDE_DEBUT_F2", tolerance)
    ecarts_fin = _construire_ecarts(merged, "SOLDE_FIN_F1", "SOLDE_FIN_F2", tolerance)

    return Resultat(
        ecarts_debut=ecarts_debut,
        ecarts_fin=ecarts_fin,
        total_debut_f1=float(r1["SOLDE_DEBUT_F1"].sum()),
        total_debut_f2=float(r2["SOLDE_DEBUT_F2"].sum()),
        total_fin_f1=float(r1["SOLDE_FIN_F1"].sum()),
        total_fin_f2=float(r2["SOLDE_FIN_F2"].sum()),
        nb_comptes_f1=len(r1),
        nb_comptes_f2=len(r2),
        nb_lignes_ignorees=nb_lignes_ignorees,
        doublons=doublons,
    )


def analyser(fichier_report, fichier_balance, tolerance: float = 1.0) -> Resultat:
    """Point d'entrée unique : deux fichiers en entrée, un Resultat en sortie."""
    df1_raw = read_file(fichier_report)
    df2_raw = read_file(fichier_balance)
    cols = detecter_colonnes(df1_raw, df2_raw)
    r1, nb_ignorees, dup1 = preparer_report_finance(df1_raw, cols)
    r2, dup2 = preparer_balance(df2_raw, cols)
    return comparer(r1, r2, tolerance, nb_ignorees, (dup1, dup2))
