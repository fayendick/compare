# -*- coding: utf-8 -*-
"""
Interface Streamlit — Comparaison des soldes
Report Finance  vs  Balance Détaillée

Ce fichier ne fait QUE de l'affichage : tous les calculs sont dans comparaison_soldes.py

Lancement :
    pip install streamlit pandas openpyxl
    streamlit run app.py
"""

import streamlit as st

from comparaison_soldes import (
    ColonnesManquantes,
    detecter_colonnes,
    fmt,
    preparer_balance,
    preparer_report_finance,
    read_file,
    comparer,
)

st.set_page_config(page_title="Comparaison des soldes", layout="wide", page_icon="🔍")

st.title("🔍 Comparaison des soldes — Report Finance vs Balance Détaillée")

st.markdown(
    """
Cette application liste **uniquement les comptes qui expliquent l'écart** entre le
*Report Finance* et la *Balance Détaillée*, pour le solde **début de mois** et le solde **fin de mois**.

- ⚠️ Les lignes du *Report Finance* **sans MATRICULE_CLIENT** sont exclues avant tout calcul :
  elles n'apparaissent jamais dans les écarts.
- Un compte présent dans un seul fichier est compté comme **0** de l'autre côté.
"""
)

col_up1, col_up2 = st.columns(2)
with col_up1:
    file1 = st.file_uploader("📄 Report Finance", type=["xlsx", "xls", "csv"], key="f1")
with col_up2:
    file2 = st.file_uploader("📄 Balance Détaillée", type=["xlsx", "xls", "csv"], key="f2")

tolerance = st.sidebar.number_input(
    "Tolérance (écart ignoré en dessous de cette valeur absolue)",
    min_value=0.0, value=1.0, step=0.5,
)

if not file1 or not file2:
    st.info("⬆️ Merci d'uploader les deux fichiers pour lancer la comparaison.")
    st.stop()

# ---------------------------------------------------------------- lecture / préparation
try:
    df1_raw = read_file(file1)
    df2_raw = read_file(file2)
except Exception as e:
    st.error(f"Erreur de lecture des fichiers : {e}")
    st.stop()

try:
    cols = detecter_colonnes(df1_raw, df2_raw)
except ColonnesManquantes as e:
    st.error(f"❌ Colonnes manquantes dans {e.fichier} : {e.colonnes}")
    st.write("Colonnes détectées :", e.disponibles)
    st.stop()

with st.expander("🔎 Colonnes détectées"):
    st.write(
        f"**Report Finance** → ACCOUNT_NO=`{cols.account1}` | MATRICULE_CLIENT=`{cols.matricule}` "
        f"| Ouverture=`{cols.ouverture}` | Final=`{cols.final1}`"
    )
    st.write(
        f"**Balance Détaillée** → Numéro de compte=`{cols.account2}` "
        f"| Début=`{cols.debut2}` | Fin=`{cols.fin2}`"
    )

r1, nb_ignorees, dup1 = preparer_report_finance(df1_raw, cols)
r2, dup2 = preparer_balance(df2_raw, cols)
res = comparer(r1, r2, tolerance, nb_ignorees, (dup1, dup2))

if dup1 or dup2:
    st.warning(
        f"⚠️ Doublons de comptes détectés (Report Finance : {dup1}, Balance Détaillée : {dup2}). "
        "Les montants ont été additionnés par compte."
    )

st.success(
    f"✅ Report Finance : {res.nb_comptes_f1} comptes retenus "
    f"({res.nb_lignes_ignorees} lignes ignorées car sans matricule client). "
    f"Balance Détaillée : {res.nb_comptes_f2} comptes."
)

# ------------------------------------------------------------------------- indicateurs
st.header("📊 Écarts globaux")

c1, c2, c3 = st.columns(3)
c1.metric("Total début — Report Finance", fmt(res.total_debut_f1))
c2.metric("Total début — Balance Détaillée", fmt(res.total_debut_f2))
c3.metric("Écart début de mois", fmt(res.ecart_total_debut))

c4, c5, c6 = st.columns(3)
c4.metric("Total fin — Report Finance", fmt(res.total_fin_f1))
c5.metric("Total fin — Balance Détaillée", fmt(res.total_fin_f2))
c6.metric("Écart fin de mois", fmt(res.ecart_total_fin))

# ------------------------------------------------------------- comptes à l'origine
st.header("🚨 Comptes à l'origine de l'écart")

tab1, tab2 = st.tabs(["Solde début de mois", "Solde fin de mois"])


def _afficher(df, ecart_total, ecart_explique, libelle):
    st.caption(
        f"{len(df)} compte(s) au-dessus de la tolérance — "
        f"écart expliqué : **{fmt(ecart_explique)}** sur un écart total de **{fmt(ecart_total)}** "
        f"(reste : {fmt(ecart_total - ecart_explique)})."
    )
    if df.empty:
        st.success(f"Aucun écart sur le {libelle} au-delà de la tolérance.")
        return
    st.dataframe(
        df.rename(columns={
            "ACCOUNT_NO": "Compte",
            "SOLDE_F1": "Report Finance",
            "SOLDE_F2": "Balance Détaillée",
            "ECART": "Écart (F1 - F2)",
            "ORIGINE": "Origine",
        }),
        use_container_width=True,
        hide_index=True,
    )
    st.download_button(
        f"⬇️ Télécharger les écarts — {libelle} (CSV)",
        data=df.to_csv(index=False).encode("utf-8-sig"),
        file_name=f"ecarts_{libelle.replace(' ', '_')}.csv",
        mime="text/csv",
        key=f"dl_{libelle}",
    )


with tab1:
    _afficher(res.ecarts_debut, res.ecart_total_debut, res.ecart_explique_debut, "solde debut")

with tab2:
    _afficher(res.ecarts_fin, res.ecart_total_fin, res.ecart_explique_fin, "solde fin")
